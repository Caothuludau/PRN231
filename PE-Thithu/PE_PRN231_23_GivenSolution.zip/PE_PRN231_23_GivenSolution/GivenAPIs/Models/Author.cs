﻿using System;
namespace GivenAPIs.Models
{
	public class Author
	{
		public Author()
		{
		}

		public int AuthorId { get; set; }
		public string Name { get; set; }
	}
}

