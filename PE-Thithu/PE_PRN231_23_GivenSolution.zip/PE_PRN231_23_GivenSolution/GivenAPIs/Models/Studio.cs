﻿using System;
namespace GivenAPIs.Models
{
	public class Studio
	{
		public Studio()
		{
		}

		public int StudioId { get; set; }
		public string StudioName { get; set; }
	}
}

