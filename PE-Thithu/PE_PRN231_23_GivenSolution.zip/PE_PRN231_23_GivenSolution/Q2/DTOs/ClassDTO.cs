﻿namespace Q2.DTOs
{
    public class ClassDTO
    {
        public ClassDTO() { }
        public string ClassName { get; set; }
    }
}
