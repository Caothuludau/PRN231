﻿namespace Q2.DTOs
{
    public class SubjectDTO
    {
        public SubjectDTO() { }
        public string Subject1 { get; set; }
    }
}
